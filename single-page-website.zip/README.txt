Single Page Website — UI Implementation
--------------------------------------

Files:
- index.html
- assets/css/style.css
- assets/js/main.js
- assets/images/hero-screenshot.png

How to view:
Open index.html in your browser. The layout is responsive for desktop/tablet/mobile.

Notes:
- Colors follow a dark theme with orange accent (--accent).
- Images are placeholders; replace assets/images/hero-screenshot.png with specific assets if you want.
